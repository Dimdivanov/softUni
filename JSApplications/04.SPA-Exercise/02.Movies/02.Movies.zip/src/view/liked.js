
export function like(params) {
    console.log('like was clicked');
}